*************************************************************************
   ____  ____ 
  /   /\/   / 
 /___/  \  /   
 \   \   \/    � Copyright 2015-2019 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary 
  /   /        information of Xilinx, Inc. and is protected under U.S. 
 /___/   /\    and international copyright and other intellectual 
 \   \  /  \   property laws. 
  \___\/\___\ 
 
*************************************************************************

Vendor: Xilinx 
Current readme.txt Version: 1.5
Date Last Modified:  04APR2018
Date Created:        14NOV2014

Associated Filename: xapp1248.zip
Associated Document: XAPP1248, Implementing SMPTE SDI Interfaces with Kintex� UltraScale GTH Transceivers

Supported Device(s): Kintex UltraScale FPGAs with GTH transceivers. 
                     SDI interfaces can be implemented in any speed grade device.
                     The demos in this zip file only work with -2 speed grade or faster.
   
*************************************************************************

Disclaimer: 

      This disclaimer is not a license and does not grant any rights to 
      the materials distributed herewith. Except as otherwise provided in 
      a valid license issued to you by Xilinx, and to the maximum extent 
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE 
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL 
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, 
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and 
      (2) Xilinx shall not be liable (whether in contract or tort, 
      including negligence, or under any other theory of liability) for 
      any loss or damage of any kind or nature related to, arising under 
      or in connection with these materials, including for any direct, or 
      any indirect, special, incidental, or consequential loss or damage 
      (including loss of data, profits, goodwill, or any type of loss or 
      damage suffered as a result of any action brought by a third party) 
      even if such damage or loss was reasonably foreseeable or Xilinx 
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or 
      for use in any application requiring fail-safe performance, such as 
      life-support or safety devices or systems, Class III medical 
      devices, nuclear facilities, applications related to the deployment 
      of airbags, or any other applications that could lead to death, 
      personal injury, or severe property or environmental damage 
      (individually and collectively, "Critical Applications"). Customer 
      assumes the sole risk and liability of any use of Xilinx products 
      in Critical Applications, subject only to applicable laws and 
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS 
FILE AT ALL TIMES.

*************************************************************************

This readme file contains these sections:

1. REVISION HISTORY
2. OVERVIEW
3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS
4. DESIGN FILE HIERARCHY
5. INSTALLATION AND OPERATING INSTRUCTIONS
6. OTHER INFORMATION
7. SUPPORT


1. REVISION HISTORY 

            Readme  
Date        Version      Revision Description
=========================================================================
04APR2018  1.5          Added Hot-Plug logic and controlled through 
                        EN_HOT_PLUG_LOGIC parameter (default is 0)
01FEB2018  1.4          Fixed CDC warnings and added CDC synchronizers
                        Upgraded the XAPP codebase to 2017.4 Vivado
                        Updated XDC Constraints
                        Incorporated latest encrypted NI-DRU codebase
                        Updated <>_drp_control_fsm with FSM encoding, 
                              registed drprdy_in and used synchronous reset 
                              for state machine
                        Fixed reference clock connections to GT COMMON in
                              all of the GTH wrapper support modules 
                        Updated DRP control state machine modules
                        Fixed ST352 payload for 4K resolutions in <>_vidgen
                        Updated code comments
08NOV2017  1.1          Updated package with the latest UHD-SDI core and to
						fix customer reported bugs.
16APR2015  1.0          Updated package with the latest UHD-SDI core and to
						fix customer reported bugs.
03FEB2015  0.3          Updated package with the latest UHD-SDI core and to
						fix customer reported bugs.
13JAN2015  0.2          Updated usage instructions.
14NOV2014  0.1          Initial Xilinx pre-release.
=========================================================================

2. OVERVIEW

This readme describes how to use the files that come with XAPP1248.

There are two example SDI designs provided with XAPP1248. 

One design has one SDI receivers and one SDI transmitters. The receiver and 
transmitter are independent of each other. The SDI transmitter is driven
by video pattern generator. The data received by the SDI receiver is captured
by Vivado ILA module.

3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS
* Vivado 2017.4 or newer
HW Requirements:
1. KCU105 development board with Production XCKU040
2. 12GSDI FMC card - TB-FMCH-12GSDI
3. HD-BNC to BNC adapters
4. High Quality coax cable for 12G SDI

4. DESIGN FILE HIERARCHY

The directory structure underneath this top-level folder is described 
below:

\kcu105_uhdsdi_demo_script.tcl
 |  This TCL needs to be executed in the TCL console of a newly opened 
 |  Vivado 2017.4 to begin reference design project compilation.
 |
\ready_for_download
 |	This folder contains FPGA configuration bit files and debugger probes (.ltx) files
 +--------\demo
 |         This directory contains the Vivado project, TCL script, bit file and debugger probes 
 |         for the UHD-SDI demonstration. The bit_files.tcl must be executed in a Blank Vivado
 |         TCL console to automatically configure FPGA and load the Vivado Hardware Manager
 |         UHD-SDI Demo Configuration. 
 |
\srcs
 |  This folder contains all the source files for the UHD-SDI reference design.
 +--------\dru
 |         This directory contains the data recovery unit (DRU) code required
 |         to receive 270 Mb/s SD-SDI. The nidru_20_wrapper.vhd, nidru_20_v_7.vhd
 |         bs_flex_v_2.vhd files are the pre-synthesized DRU IP. 
 |
 +--------\fidus_fmc_ctlr
 |         This directory contains the TCL file and SW application of the IPI
 |         subsystem to control the inrevium TB-FMCH-12SGI FMC card.
 +----------------\ipi_fidus_fmc_ctlr.tcl
 |                 This is the TCL file that constructs the MicroBlaze IPI subsystem.
 +----------------\SW
 |                 This directory contains the SW application that gets associated to
 |                 the MicroBlaze to do the FMC card initialization.
 |
 +--------\kcu105_uhdsdi_demo
 |         This directory contains the HDL and other files unique to the SDI demo.
 +----------------\uhd_sdi_vidgen
 |                 This folder contains the SDI video pattern generator files
 |
 +--------\v_smpte_uhdsdi_wrapper
 |         This directory contains SDI Wrapper Support, SDI Wrapper and other
 |         control module files for a UHD-SDI core instance. There are 8 different
 |         wrapper folders in this directory. Usage and instantiation depends on the UHD-SDI
 |         IP configuration.

5. INSTALLATION AND OPERATING INSTRUCTIONS 

Configuring FPGA with Pre-compiled Bit File
1.  Unzip xapp1248.zip
2.  Connect to the KCU105 via the UART USB port
3.  Power on the KCU105.
4.  Conect to the KCU105 System Controler and set the VADJ to 1.8V
    Note, the single microUSB connector provides access to both the Zynq system controller's
    UART and to the UltraScale FPGA's UART.  In the Windows Device Manager, the Enhanced COM
    port associated with the CP210x, is the one connected to the System Controller.

	Open a Terminal window (115200, 8, N, 1) and set the COM port to the one communicating 
	with the KCU105 System Controller. (Note, the single microUSB connector provides access
    to both the Zynq system controller's UART and to the UltraScale FPGA's UART.)
    In the Windows Device Manager, the Enhanced COM port associated with the CP210x, is the
    one connected to the System Controller.
	  
	Once UART terminal are connected, power cycle the KCU105 to refresh the System Controller Menu
	in the UART terminal. Select the following option in the System Controller Menu.
		"4. Adjust FPGA Mezzanine Card (FMC) Settings"
	then in the next menu, select:
		"4. Set  FMC VADJ   to 1.8V"
5.  Look for the VADJ power good on DS19 LED located near the power switch  on the KCU105 board.
6.  Connect up the KCU105 via the JTAG USB port
7.  In Vivado TCL Console, Key-in the following sequentially
    a.  cd <unzip_dir>\ready_for_download
    b.  source bit_files.tcl
8.  Wait for project load and the FPGA to program.

Note: If the UHD-SDI RX is not locking, make sure that the VADJ power to FMCH port is at 1.8V
      VADJ power good is indicated by DS19 LED located near the power switch of the KCU105 board.
      If the LED is off, the VADJ power can be set through KCU105's system controller's UART interface.
	  
More detailed instructions for running the demos from the provided bit files are provided in
application note.

--------------------------------------------------------------------------------
The instructions below describe how to build the demos from the supplied Verilog
source code.

Compiling the reference design is done in 4 easy steps and takes about 30 minutes to finish. Follow the instructions below to begin the compilation.
    1.	Unzip XAPP1248.zip 
    2.	Open Vivado 2017.4
    3.	In Vivado TCL Console, Key-in the following sequentially
            a. cd <unzip_dir>\XAPP1248
            b. source kcu105_uhdsdi_demo_script.tcl
    4.	Wait for project compilation to finish

The kcu105_uhdsdi_demo_script TCL executes 6 steps to complete the bitstream generation.
    1.	Creating Project
    2.	Importing RTL sources
    3.	Adding design constraint files
    4.	Generating Xilinx IPs
    	a.	tx_vio
    	b.	rx_vio
    	c.	rx_ila
    	d.	GT Wizard IP for x0y16 (v_smpte_uhdsdi_gtwiz_x0y16)
    5.	Build IPI Subsystem for inrevium 12G-SDI FMC Card control 
    6.	Running compilation

Recompiling FMC controller SDK Project

The SDK environment needs to be prepared after the completion of �kcu105_uhdsdi_demo_script.tcl� script, this is done by exporting the project�s 
hardware information and importing the SDK source codes.
	1.	Export hardware: In Vivado 2017.4 select, File->Export->Export Hardware
		a.	In the Export Hardware pop-up window, Check Include bitstream option
		b.	Set the Export to: field correspondingly					
				<unzip_dir>\XAPP1248\srcs\fidus_fmc_ctlr\SW 
	2.	Launch Xilinx SDK 2017.4 select, File->Launch SDK 
		a.	Set both Exported location and Workspace fields to:
				<unzip_dir>\XAPP1248\srcs\fidus_fmc_ctlr\SW
		b.	Once in SDK, create a new Board Support Package; File->New->Board Support Package. Assign Project Name as fidus_fmc_ctlr_bsp then click Finish
		c.	In Board Support Package Settings, click OK
	3.	Import SDK Sources: In SDK 2017.4 select, File->Import
		a.	In the Import pop-up window, select General->Existing Projects into Workspace
		b.	Click Next 
		c.	Click on Browse� button, and make sure that it points to the corresponding folders
			<unzip_dir>\XAPP1248\srcs\fidus_fmc_ctlr\SW
		d.	Click OK
		e.	Make sure fidus_fmc_ctlr is checked
		f.	Click Finish
	4.	Assign fidus_fmc_ctlr_bsp to fidus_fmc_ctlr
		a.	In SDK, right click on fidus_fmc_ctlr folder
		b.	Click on Change Referenced BSP
		c.	Select fidus_fmc_ctlr_bsp and click OK


6. OTHER INFORMATION

7. SUPPORT

To obtain technical support for this reference design, go to 
www.xilinx.com/support to locate answers to known issues in the Xilinx
Answers Database or to create a WebCase.  
